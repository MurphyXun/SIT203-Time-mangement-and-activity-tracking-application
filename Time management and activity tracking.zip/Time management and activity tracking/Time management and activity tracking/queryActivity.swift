//
//  File.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 12/12/16.
//  Copyright © 2016 Xun Sun. All rights reserved.
//

import Foundation

class queryActivity {
    static let share = queryActivity()
    static var dbactivity: databaseActivity!
    
    // MARK:- post请求
    func postWithPath(path: String,paras: Dictionary<String,Any>?,success: @escaping ((_ result: Any) -> ()),failure: @escaping ((_ error: Error) -> ())) {
        
        
        
        var i = 0
        var address: String = ""
        
        if let paras = paras {
            
            for (key,value) in paras {
                
                if i == 0 {
                    
                    address += "\(key)=\(value)"
                }else {
                    
                    address += "&\(key)=\(value)"
                }
                
                i += 1
            }
        }
        let url = URL(string: path)
        var request = URLRequest.init(url: url!)
        request.httpMethod = "POST"
        print(address)
        request.httpBody = address.data(using: .utf8)
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request) { (data, respond, error) in
            if error != nil {
                print(error!)
            }else {
                do {
                    print(respond!)
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:Any]
                    print("success")
                    
                    print(parsedData)
                    
//                    queryActivity.dbactivity = try databaseActivity(json: parsedData)
//                    print(queryActivity.dbactivity.name)
//                    print(queryActivity.dbactivity.start)
//                    print(queryActivity.dbactivity.end)
//                    print(queryActivity.dbactivity.note)
                    
                    
                }catch let error as NSError {
                    
                    print(error)
                    
                }
            }
            
            
        }
        dataTask.resume()
    }
    
}



