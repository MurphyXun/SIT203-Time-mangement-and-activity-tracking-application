//
//  TimeLineView.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 24/1/17.
//  Copyright © 2017 Xun Sun. All rights reserved.
//

import UIKit

protocol addActivityButtonDelegate {
    func popAddActivityVC()
}

class timeLine: UIView {
    public var delegate: addActivityButtonDelegate?
    
    private let momentWidth = screenWidth / 7
    private let momentHeight = 30
    private let edgeSpace = 20
    
    
    private var activityBar = UIScrollView()
    private let activityBarHeight = 100
    private let activityIconLenth = 60
    private var activityList: [activity] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupTimeLineView()
        setupActivityBar()
    }
    
    func setupTimeLineView() {
        let timeLineView = UIScrollView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: self.frame.height - CGFloat(activityBarHeight)))
        timeLineView.contentSize = CGSize(width: screenWidth, height: CGFloat(24 * (momentHeight + edgeSpace) + edgeSpace))
        self.addSubview(timeLineView)
        
        for i in 0..<25 {
            // setup time label
            let tempMoment = UILabel(frame: CGRect(x: edgeSpace, y: edgeSpace + i * (momentHeight + edgeSpace), width: Int(momentWidth), height: momentHeight))
            if(i < 10) {
                tempMoment.text = "0\(i):00"
            }
            else {
                tempMoment.text = "\(i):00"
            }
            tempMoment.textColor = UIColor.lightGray
            timeLineView.addSubview(tempMoment)
            
            
            let temp = UIView(frame: CGRect(x: edgeSpace * 2 + Int(momentWidth), y: i * (momentHeight + edgeSpace) + edgeSpace + momentHeight / 2, width: Int(screenWidth) - 3 * edgeSpace - Int(momentWidth), height: 1))
            temp.backgroundColor = UIColor.lightGray
            timeLineView.addSubview(temp)
        }
    }
    
    func setupActivityBar() {
        activityBar = UIScrollView(frame: CGRect(x: 0, y: self.frame.maxY - 300, width: screenWidth, height: 100))
        activityBar.contentSize = CGSize(width: screenWidth, height: 100)
        // setup add activity button
        let addBtn = UIButton(frame: CGRect(x: edgeSpace, y: edgeSpace, width: activityIconLenth, height: activityIconLenth))
        addBtn.setImage(UIImage(named: "add"), for: UIControlState.normal)
        addBtn.addTarget(self, action: #selector(addActivityButtonCliked), for: UIControlEvents.touchUpInside)
        activityBar.addSubview(addBtn)
        // setup custom activity
        var i = 0
        for activity in activityList {
            let temp = UIButton(frame: CGRect(x: edgeSpace + (edgeSpace + activityIconLenth) * (i + 1), y: edgeSpace, width: activityIconLenth, height: activityIconLenth))
            temp.setImage(UIImage(named: activity.image), for: UIControlState.normal)
            activityBar.addSubview(temp)
            i += i
        }
        self.addSubview(activityBar)
    }
    
    func addActivity(activity: activity) {
        activityList.append(activity)
        // set actvity button
        let temp = UIButton(frame: CGRect(x: edgeSpace + (edgeSpace + activityIconLenth) * activityList.count, y: edgeSpace, width: activityIconLenth, height: activityIconLenth))
        temp.setImage(UIImage(named: activity.image), for: UIControlState.normal)
        activityBar.addSubview(temp)
    }
    
    func addActivityButtonCliked() {
        if self.delegate != nil {
            self.delegate?.popAddActivityVC()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
