//
//  AddActivityViewController.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 12/1/17.
//  Copyright © 2017 Xun Sun. All rights reserved.
//

import UIKit
protocol AddActivityViewControllerDelegate {
    func passOnInformation(name: String, note: String, icon: String)
}

class AddActivityViewController: UIViewController {
    var navBar: UINavigationBar!
    var navItem = UINavigationItem()
    
    var nameTF = UITextField()
    var noteTV = UITextView()
    var iconColor: String!
    
    var delegate:AddActivityViewControllerDelegate?
    
    let boxHeight: CGFloat = 40

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        // set screen background color
        view.backgroundColor = UIColor.lightGray
        // set navigation bar
        navBar = UINavigationBar(frame: CGRect(x: 0, y: 20, width: screenWidth, height: 50))
        // set left button as navi item to return OneDay view
        let leftBtn = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.cancel,
                                      target: self, action: #selector(backToDay))
        navItem.setLeftBarButton(leftBtn, animated: true)
        
        // set right button as navi item to set activity for current day
        let rightBtn = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action: #selector(setActivity))
        navItem.setRightBarButton(rightBtn, animated: true)
        // set title for navi bar
        navItem.title = "Add Activity"
        // push items on navibar
        navBar.pushItem(navItem, animated: true)
        // aad navi bar into view
        view.addSubview(navBar)
        
        
        // set stack1 which contains "title" and "location"
        let stack1 = UIStackView(frame: CGRect(x: 0, y: 100, width: screenWidth, height: boxHeight))
        stack1.axis = .vertical
        stack1.alignment = .fill
        stack1.distribution = .fillEqually
        view.addSubview(stack1)
        
        //set title stack
        let stackOfTitle = UIStackView()
        stackOfTitle.axis = .horizontal
        stackOfTitle.alignment = .fill
        stack1.addArrangedSubview(stackOfTitle)
        // add title label into title stack
        let nameLB = UILabel()
        nameLB.text = "    Name"
        nameLB.textColor = UIColor.black
        nameLB.backgroundColor = UIColor.white
        nameLB.textAlignment = .left
        stackOfTitle.addArrangedSubview(nameLB)
        // add title textfield into title stack
        nameTF = UITextField()
        nameTF.textAlignment = .left
        nameTF.placeholder = "Title                                                        "
        nameTF.backgroundColor = UIColor.white
        stackOfTitle.addArrangedSubview(nameTF)
        // set note stack
        let stackOfNote = UIStackView(frame: CGRect(x: 0, y: stack1.frame.maxY + 20, width: screenWidth, height: boxHeight*3))
        stackOfNote.axis = .horizontal
        stackOfNote.alignment = .fill
        view.addSubview(stackOfNote)
        // add note label into note stack
        let noteLB = UILabel()
        noteLB.text = "    Note       "
        noteLB.textColor = UIColor.black
        noteLB.backgroundColor = UIColor.white
        noteLB.textAlignment = .left
        stackOfNote.addArrangedSubview(noteLB)
        // add note textfield
        noteTV = UITextView()
        //noteTF.sizeThatFits(CGSize(width: screenWidth - 50, height: boxHeight * 3))
        noteTV.textAlignment = .left
        noteTV.backgroundColor = UIColor.white
        stackOfNote.addArrangedSubview(noteTV)
        
        
        
        // set stack2 which contains "start", "end" and "repeat"
        let stack2 = UIStackView(frame: CGRect(x: 0, y: stackOfNote.frame.maxY + 20, width: screenWidth, height: boxHeight*3))
        stack2.axis = .vertical
        stack2.alignment = .fill
        stack2.distribution = .fillEqually
        view.addSubview(stack2)
        
        let iconLB = UILabel()
        iconLB.text = "    Icon"
        iconLB.textAlignment = .left
        iconLB.backgroundColor = UIColor.white
        stack2.addArrangedSubview(iconLB)
        
        let green = UIButton()
        green.setImage(UIImage(named: "green"), for: UIControlState.normal)
        green.addTarget(self, action: #selector(selectGreen), for: UIControlEvents.touchUpInside)
        stack2.addArrangedSubview(green)
        
        let blue = UIImageView()
        blue.image = UIImage(named: "blue")
        stack2.addArrangedSubview(blue)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func selectGreen() {
        iconColor = "green"
    }
    
    private func selectBlue() {
        iconColor = "blue"
    }
    
    // go back to OneDay VIEW
    func backToDay() {
        self.dismiss(animated: true, completion: nil)
    }
    
    // set activity for current day
    func setActivity() {
        // if user have set activity
        if(nameTF.text != "" && iconColor != nil)
        {
            // check delegate
            if(self.delegate != nil) {
                self.delegate?.passOnInformation(name: nameTF.text!, note: noteTV.text, icon: iconColor)
            }
            self.dismiss(animated: true, completion: nil)
        }
    }
}

