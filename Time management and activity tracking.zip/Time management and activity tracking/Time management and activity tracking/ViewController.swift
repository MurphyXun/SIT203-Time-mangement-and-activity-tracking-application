//
//  ViewController.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 9/12/16.
//  Copyright © 2016 Xun Sun. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    
    var emailTF: UITextField!
    var passwordTF: UITextField!
    var signInBtn: UIButton!
    var emailEntered = false
    var passwordEntered = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        view.backgroundColor = UIColor(patternImage: UIImage(named:"Log In Screen.png")!)
        
        // app name label
        let appnameLB = UILabel(frame: CGRect(x: screenWidth / 2 - 70, y: 100, width: 200, height: 80))
        appnameLB.text = "TimeTracker"
        appnameLB.textColor = UIColor.white
        appnameLB.font = UIFont(name:"Zapfino", size:20)
        view.addSubview(appnameLB)
        
        // set email textfield on screen 
        emailTF = UITextField(frame: CGRect(x: 20, y: appnameLB.frame.maxY + 50, width: screenWidth - 40, height: 40))
        emailTF.borderStyle = .roundedRect
        emailTF.placeholder = "Email"
        // set it translucent
        emailTF.backgroundColor = UIColor.init(red: 255, green: 255, blue: 255, alpha: 0)
        emailTF.textColor = UIColor.white
        emailTF.addTarget(self, action: #selector(checkEmail), for: UIControlEvents.editingDidEnd)
        view.addSubview(emailTF)
        
        // set password TF on screen
        passwordTF = UITextField(frame: CGRect(x: 20, y: emailTF.frame.maxY + 20, width: screenWidth - 40, height: 40))
        passwordTF.borderStyle = .roundedRect
        passwordTF.placeholder = "Password"
        passwordTF.backgroundColor = UIColor.init(red: 255, green: 255, blue: 255, alpha: 0)
        passwordTF.textColor = UIColor.white
        passwordTF.isSecureTextEntry = true
        passwordTF.addTarget(self, action: #selector(checkPassword), for: UIControlEvents.allEvents)
        view.addSubview(passwordTF)
        
        // set sign in button
        signInBtn = UIButton(type: UIButtonType.system)
        signInBtn.frame = CGRect(x: 20, y: passwordTF.frame.maxY + 30, width: screenWidth - 40, height: 40)
        signInBtn.setTitle("Sign in", for: UIControlState.normal)
        signInBtn.setBackgroundImage(UIImage(named:"green.png")!, for: UIControlState.normal)
        signInBtn.setTitleColor(UIColor.white, for: UIControlState.normal)
        signInBtn.addTarget(self, action: #selector(signIn), for: UIControlEvents.touchUpInside)
        signInBtn.isEnabled = false
        view.addSubview(signInBtn)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // check if Email is entered
    func checkEmail() {
        if emailTF.text != "" {
            emailEntered = true
        }
        if(emailEntered && passwordEntered)
        { // if both entered, then signBTN is enable
            signInBtn.isEnabled = true
        }
    }
   
    // check if email is entered
    func checkPassword() {
        if passwordTF.text != "" {
            passwordEntered = true
        }
        if(emailEntered && passwordEntered)
        { // if both entered, then signBTN is enable
            signInBtn.isEnabled = true
        }
    }
//    @IBAction func login_button_click(_ sender: Any) {
//        if(account_tf.text == "")
//        {
//            account_tf.text = "murphy"
//        }
//        else
//        {
//            // php file connect to databse
//            let url = "http://www.deakin.edu.au/individuals-sites/?request=~sunx/project/test.php"
//            let dictionary:Dictionary<String,Any> = ["yesButton" : "Proceed", "requested_url" : "~sunx/project/test.php"]
//            
//            HttpConnectTool.share.postWithPath(path: url, paras: dictionary, success: { (result) in print(result)}, failure: { (error) in print(error)})
//            
//            let calendarView = CalendarViewController()
//            self.present(calendarView, animated: true, completion: nil)
//            
//        }
//        
//    }
    func signIn() {
            
            // login check php
            
            // jump into calendar view
            let calendarView = CalendarViewController()
            self.present(calendarView, animated: true, completion: nil)
    }
}

