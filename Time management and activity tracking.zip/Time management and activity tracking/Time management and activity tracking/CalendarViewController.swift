//
//  CalendarViewController.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 11/1/17.
//  Copyright © 2017 Xun Sun. All rights reserved.
//

import UIKit

struct oneDay {
    var year: Int
    var month: Int
    var date: Int
}

// get the height and with of main screen
let screenHeight = UIScreen.main.bounds.size.height
let screenWidth = UIScreen.main.bounds.size.width


class CalendarViewController: UIViewController, addActivityButtonDelegate, AddActivityViewControllerDelegate {
    
    var time: timeLine!
    var calendarView: UICollectionView!
    var weekdays = ["Su","Mo","Tu","We","Th","Fr","Sa"]
    
    var today = day()
    var threeWeekDays: [oneDay] = []
    
    
    let activityToolBarHeight = 100
    // edge gap space
    let edgeGapSpace = 20

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("today's weekday is \(today.weekday)")
        setupCalendarView()
        // add time line on screen
        time = timeLine(frame: CGRect(x: 0, y: calendarView.frame.maxY, width: screenWidth, height: screenHeight - calendarView.frame.height))
        // setup add actvity delegate
        time.delegate = self
        view.addSubview(time)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func setupCalendarView() {
        // set the whole view background color as white
        view.backgroundColor = UIColor.white

        
        // set the collection view to show the current month calendar
        // the number of days in one week
        let daysOfWeek = 7
        // inter item space
        let minimumInterItemSpace = 5
        // line space
        let minimumLineSpace = 5
        // edge gap space
        let edgeGapSpace = 20
        // set the layout of collection view
        let layout = UICollectionViewFlowLayout()
        let itemsTotalWidth = Int(screenWidth) - Int(edgeGapSpace) * 2 - minimumInterItemSpace * (daysOfWeek - 1)
        let itemHeight = 40
        layout.itemSize = CGSize(width: CGFloat(itemsTotalWidth / daysOfWeek), height: CGFloat(itemHeight))
        layout.minimumInteritemSpacing = CGFloat(minimumInterItemSpace)
        layout.minimumLineSpacing = CGFloat(minimumLineSpace)
        // set the collection veiw
        let collectionViewHeight = itemHeight * 4 + minimumLineSpace * 3
        calendarView = UICollectionView(frame: CGRect(x: CGFloat(edgeGapSpace), y: CGFloat(edgeGapSpace), width: screenWidth - 40, height: CGFloat(collectionViewHeight)), collectionViewLayout: layout)
        calendarView.backgroundColor = UIColor.white
        calendarView.register(DateCollectionViewCell.self, forCellWithReuseIdentifier: "dateCell")
        calendarView.delegate = self
        calendarView.dataSource = self
        view.addSubview(calendarView)
    }
    
    func popAddActivityVC() {
        let addActivity = AddActivityViewController()
        addActivity.delegate = self
        self.present(addActivity, animated: true, completion: nil)
    }
    
    func passOnInformation(name: String, note: String, icon: String) {
        let atvt = activity(name: name, image: icon)
        time.addActivity(activity: atvt)
    }
}




extension CalendarViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if(section == 0) {
            return weekdays.count
        }
        else {
            // return 21 days, last week, current week and next week
            return 21
        }
        
        
    }
    
    // deque cells and set it up
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if(indexPath.section == 0) {
            // set the cell of weekdays information
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "dateCell", for: indexPath) as! DateCollectionViewCell
            cell.awakeFromNib()
            cell.dayLB.text = weekdays[indexPath.row]
            cell.dayLB.textColor = UIColor.darkGray
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "dateCell", for: indexPath) as! DateCollectionViewCell
            cell.awakeFromNib()
            
            let i = indexPath.row
            // sunday = 0, monday = 1, ... saturday = 6
            // compute the date of last Sunday
            let temp = today.day - today.weekday - 7 + i
            if temp < 0 {
            // the day belong to last month
            // should figure out how many days in last month are there first
                let daysOfLastMonth = today.daysOfLastMonth()
                let tempDay: oneDay
                if(today.month != 1) {
                    tempDay = oneDay(year: today.year, month: today.month - 1, date: daysOfLastMonth + temp + 1)
                }
                else {
                    tempDay = oneDay(year: today.year - 1, month: 12, date: daysOfLastMonth + temp + 1)
                }
                threeWeekDays.append(tempDay)
                cell.dayLB.text = String(daysOfLastMonth + temp + 1)
            }
            else if temp > today.daysOfMonth {
            // the day belong to next month
                let tempDay: oneDay
                if(today.month == 12) {
                    tempDay = oneDay(year: today.year + 1, month: 1, date: temp - today.daysOfMonth)
                }
                else {
                    tempDay = oneDay(year: today.year, month: today.month + 1, date: temp - today.daysOfMonth)
                }
                threeWeekDays.append(tempDay)
                cell.dayLB.text = String(temp - today.daysOfMonth)
            }
            else {
            // normal
                let tempDay = oneDay(year: today.year, month: today.month, date: temp)
                threeWeekDays.append(tempDay)
                cell.dayLB.text = String(temp)
            }
            
            
            if(today.weekday + 7 == i) {
                // set different color for today
                cell.dayLB.textColor = UIColor.black
            }
            else if (today.weekday + 7 > i) {
                cell.dayLB.textColor = UIColor.lightGray
            }
            else {
                cell.dayLB.textColor = UIColor.gray
            }
            return cell
        }
        
    }
}
