//
//  UserClass.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 16/12/16.
//  Copyright © 2016 Xun Sun. All rights reserved.
//

import Foundation

struct User{
    let id: Int
    let name: String
}

enum SerializationError: Error {
    case missing(String)
    case invalid(String, Any)
}

extension User{
    init(json: [String: Any]) throws {
        guard let userData = json["data"] as? [String: Any] else{
            throw SerializationError.missing("data")
        }
        
        guard let id = userData["id"] as? Int else{
            throw SerializationError.missing("id")
        }
        
        guard let name = userData["name"] as? String  else {
            throw SerializationError.missing("name")
        }
        
        self.id = id
        self.name = name
        
    }
}
