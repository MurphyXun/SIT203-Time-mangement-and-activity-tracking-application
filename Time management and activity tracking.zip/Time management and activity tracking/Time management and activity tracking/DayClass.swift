//
//  Day.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 12/1/17.
//  Copyright © 2017 Xun Sun. All rights reserved.
//

import Foundation


class day {
    var year: Int
    var month: Int
    var day: Int
    var hour: Int
    var minute: Int
    var second: Int
    var weekday: Int
    var daysOfMonth: Int
    var isLeap: Bool
    
    init() {
        let calendar: Calendar = Calendar(identifier: .gregorian)
        var comps: DateComponents = DateComponents()
        comps = calendar.dateComponents([.year,.month,.day, .weekday, .hour, .minute,.second], from: Date())
        year = comps.year!
        month = comps.month!
        day = comps.day!
        hour = comps.hour!
        minute = comps.minute!
        second = comps.second!
        // sunday = 0, monday = 1, ... saturday = 6
        weekday = comps.weekday! - 1
        
        if(comps.year! % 400 == 0) {
            isLeap = true
            switch comps.month! {
            case 1,3,5,7,8,10,12 : daysOfMonth = 31
            case 2: daysOfMonth = 29
            case 4,6,9,11 : daysOfMonth = 30
            default: daysOfMonth = 0
            }
        }
        else if(comps.year! % 100 != 0 && comps.year! % 4 == 0 ) {
            isLeap = true
            switch comps.month! {
            case 1,3,5,7,8,10,12 : daysOfMonth = 31
            case 2: daysOfMonth = 29
            case 4,6,9,11 : daysOfMonth = 30
            default: daysOfMonth = 0
            }
        }
        else {
            isLeap = false
            switch comps.month! {
            case 1,3,5,7,8,10,12 : daysOfMonth = 31
            case 2: daysOfMonth = 28
            case 4,6,9,11 : daysOfMonth = 30
            default: daysOfMonth = 0
            }
        }
        
        
    } // init end
    
    // return the days of last month
    func daysOfLastMonth() -> Int {
        var days = 0
        if(year - 1 % 400 == 0) {
            switch month {
            case 1,2,4,6,8,9,11 : days = 31
            case 3: daysOfMonth = 29
            case 5,7,10,12 : daysOfMonth = 30
            default: daysOfMonth = 0
            }
        }
        else if(year - 1 % 100 != 0 && year - 1 % 4 == 0 ) {
            switch month {
            case 1,2,4,6,8,9,11 : daysOfMonth = 31
            case 3: daysOfMonth = 29
            case 5,7,10,12 : daysOfMonth = 30
            default: daysOfMonth = 0
            }
        }
        else {
            switch month {
            case 1,2,4,6,8,9,11 : daysOfMonth = 31
            case 3: daysOfMonth = 28
            case 5,7,10,12 : daysOfMonth = 30
            default: daysOfMonth = 0
            }
        }
        return days
    }
    
    // compute the weekday of the first day in this month
    func firstWeekdayInThisMonth() -> Int {
        var firstWeekday: Int
        let tmp = weekday - (day % 7)
        
        //print("weekday: \(weekday)")
        if(tmp >= 0) {
            firstWeekday = (tmp) % 7
        }
        else {
            firstWeekday = (tmp + 7) % 7
        }
        return firstWeekday
    }
    
}



















//// get the information of current time
//func getTimes() -> Dictionary<String, Int> {
//    
//    var timers: Dictionary<String, Int> = [:] //  返回的数组
//    
//    let calendar: Calendar = Calendar(identifier: .gregorian)
//    var comps: DateComponents = DateComponents()
//    comps = calendar.dateComponents([.year,.month,.day, .weekday, .hour, .minute,.second], from: Date())
//    var daysOfMonth: Int = 0
//    
//    timers["year"] = comps.year!
//    timers["month"] = comps.month!
//    timers["day"] = comps.day!
//    timers["hour"] = comps.hour!
//    timers["minute"] = comps.minute!
//    timers["second"] = comps.second!
//    timers["weekday"] = comps.weekday! - 1
//    
//    
//    
//    //        timers.append( "year" : comps.year!)  // 年 ，后2位数
//    //        timers.append(comps.month!)            // 月
//    //        timers.append(comps.day!)                // 日
//    //        timers.append(comps.hour!)               // 小时
//    //        timers.append(comps.minute!)            // 分钟
//    //        timers.append(comps.second!)            // 秒
//    //        timers.append(comps.weekday! - 1)      //星期
//    
//    if(comps.year! % 400 == 0) {
//        switch comps.month! {
//        case 1,3,5,7,8,10,12 : daysOfMonth = 31
//        case 2: daysOfMonth = 29
//        case 4,6,9,11 : daysOfMonth = 30
//        default: daysOfMonth = 0
//        }
//    }
//    else if(comps.year! % 100 != 0 && comps.year! % 4 == 0 ) {
//        switch comps.month! {
//        case 1,3,5,7,8,10,12 : daysOfMonth = 31
//        case 2: daysOfMonth = 29
//        case 4,6,9,11 : daysOfMonth = 30
//        default: daysOfMonth = 0
//        }
//    }
//    else {
//        switch comps.month! {
//        case 1,3,5,7,8,10,12 : daysOfMonth = 31
//        case 2: daysOfMonth = 28
//        case 4,6,9,11 : daysOfMonth = 30
//        default: daysOfMonth = 0
//        }
//    }
//    
//    timers["daysOfMonth"] = daysOfMonth
//    //print(daysOfMonth)
//    
//    return timers;
//}
