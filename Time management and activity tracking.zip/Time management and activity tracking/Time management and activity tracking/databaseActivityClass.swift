//
//  databaseActivityClass.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 15/1/17.
//  Copyright © 2017 Xun Sun. All rights reserved.
//

import Foundation

struct databaseActivity{
    let start: Int
    let end: Int
    let note: String
    let name: String
}

extension databaseActivity{
    init(json: [String: Any]) throws {
        guard let userData = json["data"] as? [String: Any] else{
            throw SerializationError.missing("data")
        }
        
        guard let start = userData["start"] as? Int else{
            throw SerializationError.missing("id")
        }
        
        guard let name = userData["name"] as? String  else {
            throw SerializationError.missing("name")
        }
        
        guard let end = userData["end"] as? Int  else {
            throw SerializationError.missing("name")
        }
        
        guard let note = userData["note"] as? String  else {
            throw SerializationError.missing("name")
        }
        
        self.start = start
        self.name = name
        self.note = note
        self.end = end
    }
}
