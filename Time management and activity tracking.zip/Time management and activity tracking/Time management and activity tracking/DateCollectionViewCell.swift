//
//  DateCollectionViewCell.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 11/1/17.
//  Copyright © 2017 Xun Sun. All rights reserved.
//

import UIKit

class DateCollectionViewCell: UICollectionViewCell {
    
    var dayLB: UILabel!
    
    override func awakeFromNib() {
        
        dayLB = UILabel(frame: CGRect(x: contentView.frame.minX, y: contentView.frame.minY, width: 40, height: contentView.frame.height))
        dayLB.textAlignment = .center
        dayLB.textColor = UIColor.lightGray
        dayLB.font = UIFont(name:"Avenir", size:20)
        contentView.addSubview(dayLB)
    }
}
