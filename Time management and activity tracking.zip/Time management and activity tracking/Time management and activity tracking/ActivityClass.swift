//
//  ActivityClass.swift
//  Time management and activity tracking
//
//  Created by Xun Sun on 11/1/17.
//  Copyright © 2017 Xun Sun. All rights reserved.
//

import Foundation

class activity {
    var name: String
    var image: String
    
    init(name: String, image: String) {
        self.name = name
        self.image = image
    }
}

class settedActivity: activity {
    var startDT: Date!
    var endDT: Date!
    var note: String!
    
    init(name: String, image: String, note: String, startDT: Date, endDT: Date) {
        super.init(name: name, image: image)
        self.note = note
        self.startDT = startDT
        self.endDT = endDT
    }
}
